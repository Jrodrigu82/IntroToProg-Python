'''
Andres Rodriguez
May 15, 2017
Assignment 7-------
#-- Input/Output --
# # User can see a Menu (Step 2) 
# User can see data (Step 3)
 # User can insert or delete data(Step 4 and 5)
 # User can save to file (Step 6)  
#-- Processing --
# # Step 1 # When the program starts, load the any data you have # in a text file called ToDo.txt into a python Dictionary.
  # Step 2 # Display a menu of choices to the user  # Step 3 # Display all todo items to user  # Step 4 #
 Add a new item to the list/Table
  # Step 5 # Remove a new item to the list/Table 
 # Step 6 # Save tasks to the ToDo.txt file
  # Step 7 # Exit program

'''
import os
desktop = os.path.join(os.path.expanduser("~"), "Desktop")

#-----Data----------------------------
# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
strData= "" # variable assigned to text separated by coma in the existing todo.txt file
dicRow={} # varible that set all row into a dictionary
lstTable=[] #variable that nest dictionary rows into a list
filePath = os.path.join(desktop, "ToDo.txt") # variable that contains the path to todo.txt file
objFileName = open(filePath, 'r') #varariavle that open and read txt file
strChoice="" #variable for main menu user input
strToDo="" #varaible for user input to add a todo item ton the list
strPriority="" #varaible for user input to add a priority
strkeyRemove="" #varaible for user input to remove an item
blnActionRemoved = False # variable to set a flag on the remove function
intRowIndex = 0 # variable to set index value in the remove function
strUserAnswer="" # variable to get user input in saveinput function


#---------------------------------------------Processing--------------------------------
# the function below will process all data into dictionary rows and nest the rows into a list
def readFileCreateDictList(objFileName): #this function opens and read your existing file and store the first 2 items separated by a coma
    for line in objFileName:  # reads data in the existing file and process data through the loop below
        strData = line.split(",")  # slipts data separated by a coma
        dicRow = {"ToDo": strData[0].strip(), "Priority": strData[1].strip()}  # format data in dictionary, assigns index, and strips existing data or user added data of extra spaces
        lstTable.append(dicRow)  # nest dictionary into a list
    objFileName.close()


class ToDoListOperations(object):


    @staticmethod
    def showCurrentData():
        for row in lstTable:  # for loop process all rows and print them below
            print(row["ToDo"] + "(" + row["Priority"] + ")")
            continue

    @staticmethod
    def addItemsToToDoList(strToDo,strPriority):
        while (True):  # while loop process user input and store data into dictionary and append it to the list
            dicRow = {"ToDo": strToDo, "Priority": strPriority, }  # user input data added to the dictionary
            lstTable.append(dicRow)  # User data rows are added to the list
            print("Below is the updated to do list")
            for row in lstTable:
                print(row["ToDo"] + "(" + row["Priority"] + ")")
            if (input("Would you like enter additional To Do actions? \n"
                      "Type 'exit' to quit, otherwise press any other key\n").lower() == "exit"):  # ask user if they want to continue adding data
                break
            else:
                continue
            continue

    @staticmethod
    def removeItemFromToDoList():
        blnActionRemoved = False
        intRowIndex = 0
        while (intRowIndex < len(lstTable)):
            if (strkeyRemove == str(list(dict(lstTable[intRowIndex]).values())[0])):
                del lstTable[intRowIndex]
                blnActionRemoved = True
            intRowIndex += 1
        if (blnActionRemoved == True):
            print(strkeyRemove, "Was removed from your list ")
        else:
            print(strkeyRemove, " Was not found! ")

    @staticmethod
    def SaveChanges():
        for row in lstTable:
            print(row["ToDo"] + "(" + row["Priority"] + ")")
        strUserAnswer = (input("Would You Like to Save you input(s), Type 'y'to continue,\n"
                               "Otherwise press any other Key \n"))
        if ((strUserAnswer).lower() == "y"):
            objFileName = open(filePath, 'w')
            objFileName.write(str(lstTable))
            objFileName.close()
            print("Your Data was saved in the ToDo.Txt file")
        else:
            print("Your Data was not saved !")


#----------------------------Presentation I/0-------------------------------------------------------

# Step 2 - Display a menu of choices to the user
readFileCreateDictList(objFileName)
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line
    # Step 3 -Show the current items in the table
    if (strChoice == '1'):
        ToDoListOperations.showCurrentData()
        print("If you would like to enter additional To Do actions, select 2 on the main menu")
        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice == '2'):
        strToDo = input("What you action would like to add? :\n")  # set user-input variables
        strPriority = input("What Priority? High, Medium  or Low ? :\n")  # set user-input variables
        ToDoListOperations.addItemsToToDoList(strToDo,strPriority)
        continue
    # Step 5 - Remove a new item to the list/Table

    elif (strChoice == '3'):
        strkeyRemove = input("What you action would like Remove? :\n")
        ToDoListOperations.removeItemFromToDoList()

        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        ToDoListOperations.SaveChanges()
        continue
    # Step 7 exit program
    elif (strChoice == '5'):
        break  # and Exit the program
