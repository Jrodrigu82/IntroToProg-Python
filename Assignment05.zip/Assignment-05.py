#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   <Andres Rodriguez>,05/08/2017 , Added code to complete assignment 5
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------
import os
desktop = os.path.join(os.path.expanduser("~"), "Desktop")
filePath = os.path.join(desktop, "ToDo.txt")

# Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
strData= ""
lstTable=[]

# the function below will process all data into dictionary rows and nest the rows into a list
objFileName = open(filePath,'r')
for line in objFileName:  # reads data in the existing file and process data through the loop below
    strData = line.split(",") #slipts data separated by a coma
    dicRow = {"ToDo":strData[0].strip(), "Priority":strData[1].strip()}  # format data in dictionary, assigns index, and strips existing data or user added data of extra spaces
    lstTable.append(dicRow)     # nest dictionary into a list
objFileName.close()



# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line
    # Step 3 -Show the current items in the table
    if (strChoice == '1'):
        for row in lstTable:   # for loop process all rows and print them below
            print(row["ToDo"] + "("+ row["Priority"] + ")")
        print("If you would like to enter additional To Do actions, select 2 on the main menu")
        continue
         
    # Step 4 - Add a new item to the list/Table
    elif(strChoice == '2'):

        while (True):     # while loop process user input and store data into dictionary and append it to the list
            strToDo = input("What you action would like to add? :\n") #set user-input variables
            strPriority = input("What Priority? High, Medium  or Low ? :\n")   #set user-input variables
            dicRow = {"ToDo": strToDo, "Priority": strPriority, }   # user nput data added to the dictionary

            lstTable.append(dicRow)    # User data rows are added to the list

            print ("Below is the updated to do list")
            for row in lstTable:
                print(row["ToDo"] + "("+ row["Priority"] + ")")

            if (input("Would you like enter additional To Do actions? \n"
                      "Type 'exit' to quit, otherwise press any other key\n").lower() == "exit"): # ask user if they want to continue adding data
                break
            else:
                continue
        continue
    # Step 5 - Remove a new item to the list/Table

    elif(strChoice == '3'):
        strkeyRemove = input("What you action would like Remove? :\n")
        blnActionRemoved = False
        intRowIndex = 0
        while(intRowIndex < len(lstTable)):
            if (strkeyRemove == str(list(dict(lstTable[intRowIndex]).values())[0])):
                 del lstTable [intRowIndex]
                 blnActionRemoved = True
            intRowIndex += 1
        if(blnActionRemoved == True ):
             print(strkeyRemove, "Was removed from your list ")
        else:
            print(strkeyRemove," Was not found! ")
        
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        for row in lstTable:
            print(row["ToDo"] + "("+ row["Priority"] + ")")
        strUserAnswer = (input("Would You Like to Save you input(s), Type 'y'to continue,\n"
                                "Otherwise press any other Key \n"))
        if ((strUserAnswer).lower() == "y"):
            objFileName = open(filePath, 'w')
            objFileName.write(str(lstTable))
            objFileName.close()
            print("Your Data was saved in the ToDo.Txt file")
        else:
            print("Your Data was not saved !")
        continue
    #Step 7 exit program
    elif (strChoice == '5'):
        break #and Exit the program
        